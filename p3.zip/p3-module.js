const coin = { 
    denom,
    count
}

let numbers = [1,5,10,25,50,100,101,102,103];

function validDenomination(coin) {
    if (numbers.indexOf(coin) <= 5) {
        return true;
    }
}

function valueFromCoinObject(obj) {
    const {denom = 0, count = 0} = obj;
    return count * denom;
}

function valueFromArray(arr) {
    if (arr[0]!==Array) {
    return arr.reduce(
        valueFromCoinObject()
    );
    }
    
}

export function coinCount (coinage) {
    return valueFromArray(coinage);
}
