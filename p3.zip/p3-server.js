const fs = require('fs');
const fastify = require('fastify')();
import { coinCount } from "p3-module.js";



 fastify.get(fs.readFile('index.html', (err, data) => {if (err) {console.log("500")}else{console.log("200")}console.log(data);}), (request, reply) => {
    reply
        .code(200)
        .header("Content-Type", "text/html; charset=utf-8")
        .send(
            {test: "This is a test"}
        );

 });

 fastify.get("/coin",(request, reply) => {
    const {denom = 0, count = 0} = request;
    denom = parseInt(denom);
    count = parseInt(count);
    reply.send(
        {test: coinCount(request)}
        `<h2>Value of ${count} of ${denom} is ${coinValue}</h2><br /><a href="/">Home</a>`
    );
 });

 fastify.get("/coins",(request, reply) => {
    switch (request) {
        case 1:
            reply.send(coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 })
            `<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`
);   // option = 1
            break;
        case 2:
            reply.send(coinCount(...coins
                `<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`
));    // option = 2
            break;
        case 3:
            reply.send(coinCount(coins
                `<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`
));    // Extra credit: option = 3
            break;
        default:
            reply.send(coinCount(coins
                `<h2>Option ${0} value is ${0}</h2><br /><a href="/">Home</a>`
));    // Extra credit: option = 3
            
            break;
    }

    reply.send(
        {test: coinCount(request)}
        `<h2>Value of ${count} of ${denom} is ${coinValue}</h2><br /><a href="/">Home</a>`
    );
 });

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
    if (err) {
        console.log(err);
        process.exit(1);

    }
    console.log(listenIP);
    console.log(listenPort);
    console.log(`Server listening on ${address}`);
});
